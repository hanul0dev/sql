package test.book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Q3 {
	String URL="jdbc:oracle:thin:@localhost:1521:xe";
	String USER="c##madang";
	String PWD="madang";
	Connection con;
	public Q3() {
//		JBDC Driver Memory에 Load한다.
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로드 성공");
			con=DriverManager.getConnection(URL,USER,PWD);
			System.out.println("DB 연결 성공");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	//main 메소드에서 runSQL(1) 호출, 1은 검색메뉴 값을 의미, 스포츠는 검색어를 의미
	//searchMenu가 1이면 도서명 검색, 2면 고객명 검색
	public void runSQL(int searchMenu, String searchWord) {
		
		
		String sql="";
		
		switch(searchMenu) {
		case 1:
			sql="SELECT c.name, b.bookname,o.saleprice FROM book b,customer c,orders o "
												+ "WHERE c.custid=o.custid AND b.bookid=o.bookid "
												+ "AND b.bookname LIKE '%" + searchWord + "%'ORDER BY c.name";
			break;
		case 2:
			sql="SELECT  c.name, b.bookname,o.saleprice FROM book b,customer c,orders o "
					+ "WHERE c.custid=o.custid AND b.bookid=o.bookid "
					+ "AND c.name LIKE '%" + searchWord + "%'ORDER BY c.name";
			break;
		}
		try {
			//Connetction 객체를 사용해서 문장객체를 생성 및 반환
			Statement stmt= con.createStatement();
			//Statment 객체를 사용해서 sql문을 실행
			ResultSet rs=stmt.executeQuery(sql);
			//반복문을 사용해서 ResultSet 객체의 행개수 만큼 데이터를 가져와서 콘솔에 출력
			//next()는 데이터행을 접근할 수 있는 커서를 다음 행으로 이동시키는 기능
			//실제 cursor가 가리키는 데이터행이 존재하면 true를 반환, 데이터행이 존재하지 않으면 false를 반환
			System.out.printf("%-10s","고객명");
			System.out.printf("%-20s","도서명");
			System.out.printf("\t%s\n","판매가격");
			System.out.println("===================================================");
			while(rs.next()) {
					System.out.printf("%-10s",rs.getString("name"));
					System.out.printf("%-20s",rs.getString("bookname"));
					System.out.printf("\t%7d\n",rs.getInt("saleprice"));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Q3 bList=new Q3();
		Scanner s1 = new Scanner(System.in);
		Scanner s2 = new Scanner(System.in);
		while(true) {
			System.out.println("도서명 또는 고객명으로 입력하시오");
			System.out.println("1. 도서명 2. 고객명 3. 종료");
			int searchMenu=s1.nextInt();
			String searchWord="";
			
			switch(searchMenu) {
			case 1:
				System.out.print("* 도서명의 검색어를 입력 : ");
				break;
			case 2:
				System.out.print("* 고걱명의 검색어를 입력 : ");
				break;
			case 3:
				System.out.println("시스템 종료");
				try {
					bList.con.close();		
					s1.close();
					s2.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
				return;
				
		}
		searchWord=s2.nextLine();
		
		bList.runSQL(searchMenu,searchWord);
		}
		
		
		
	}
}